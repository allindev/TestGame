﻿using UnityEngine;

public abstract class VirusBaseProp : MonoBehaviour
{
    public abstract void Excute(Transform target);

}