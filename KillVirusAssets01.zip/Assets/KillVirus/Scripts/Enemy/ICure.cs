﻿public interface ICure
{

}
