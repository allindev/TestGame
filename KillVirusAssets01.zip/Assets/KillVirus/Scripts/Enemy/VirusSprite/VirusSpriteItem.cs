﻿using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class VirusSpriteItem
{
    public List<SpriteRenderer> SpriteRenderers;

    public List<string> SpriteNames;
}