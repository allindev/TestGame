﻿using UnityEngine;

public abstract class BaseVirusSprite : MonoBehaviour
{
    public abstract void Initi(ColorLevel level);

}