﻿
public struct FirstByteClick1DownEvent
{

}

public struct FirstByteClick2DownEvent
{

}

public struct FirstByteClick3DownEvent
{

}

public struct FirstByteClick4DownEvent
{

}

public struct FirstByteClick5DownEvent
{

}

public struct FirstByteClick6DownEvent
{

}

public struct FirstByteClick7DownEvent
{

}

public struct FirstByteClick8DownEvent
{

}


public struct FirstByteClick1UpEvent
{

}

public struct FirstByteClick2UpEvent
{

}

public struct FirstByteClick3UpEvent
{

}

public struct FirstByteClick4UpEvent
{

}

public struct FirstByteClick5UpEvent
{

}



public struct ThirdByteClick1Event
{
    
}

public struct ThirdByteClick2Event
{

}

public struct ThirdByteClick3Event
{

}

public struct ThirdByteClick4Event
{

}

public struct ThirdByteClick5Event
{

}

public struct ThirdByteClick6Event
{

}

public struct ThirdByteClick7Event
{

}

public struct ThirdByteClick8Event
{

}


public struct CoinRateEvent
{
    public int CoinRate;

    public CoinRateEvent(int coinRate)
    {
        CoinRate = coinRate;
    }
}

public struct CoinAddEvent
{

}





