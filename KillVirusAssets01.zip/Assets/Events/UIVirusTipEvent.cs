﻿
namespace Events
{
    public struct UIVirusTipEvent
    {

    }
}
